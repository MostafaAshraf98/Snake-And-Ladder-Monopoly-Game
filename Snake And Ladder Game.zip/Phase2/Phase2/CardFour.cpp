#include "CardFour.h"

CardFour::CardFour(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 4;
}

void CardFour::ReadCardParameters(Grid* pGrid)
{
}

void CardFour::Apply(Grid* pGrid, Player* pPlayer)
{

	Card::Apply(pGrid, pPlayer);
	CellPosition PlayerCurrPos = pPlayer->GetCell()->GetCellPosition();
	Snake* NextSnake = pGrid->GetNextSnake(PlayerCurrPos);
	if (NextSnake != NULL)
	{
		CellPosition PlayerNewPos = NextSnake->GetPosition();
		pGrid->UpdatePlayerCell(pPlayer, PlayerNewPos);
	}


}

void CardFour::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << endl;
}


void CardFour::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
}

CardFour::~CardFour(void)
{
}
