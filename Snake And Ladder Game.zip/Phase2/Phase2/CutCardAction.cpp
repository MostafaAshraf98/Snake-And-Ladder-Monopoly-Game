#include "CutCardAction.h"
#include"Output.h"
#include"Input.h"
#include"Grid.h"
#include"Card.h"


CutCardAction::CutCardAction(ApplicationManager* pApp) : Action(pApp)
{

}

CutCardAction::~CutCardAction()
{

}

void CutCardAction::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();


	pOut->PrintMessage("Click on Source Cell...");


	CellPos = pIn->GetCellClicked();




}


void CutCardAction::Execute()
{

	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	ReadActionParameters();



	int i = CellPos.VCell();
	int j = CellPos.HCell();

	GameObject* pGameObject = pGrid->GetGameObject(i, j);

	ClipBoard = dynamic_cast<Card*>(pGameObject);



	if (ClipBoard)
	{
		CardNum = ClipBoard->GetCardNumber();


		pGrid->SetClipboard(ClipBoard);

		pGrid->RemoveObjectFromCell(CellPos);
	}
	else
	{
		pGrid->PrintErrorMessage("Error: No Card on Source Cell...");

	}


	pOut->ClearStatusBar();



}


