#pragma once

#include "Card.h"
#include "RollDiceAction.h"
#include "fstream"

class CardSeven : public Card
{

public:
	CardSeven(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid);

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of CardSeven on the passed Player
													  // by giving the player another dice roll

	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	virtual ~CardSeven(); // A Virtual Destructor
};

