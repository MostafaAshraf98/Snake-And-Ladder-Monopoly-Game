#include "CardEight.h"

CardEight::CardEight(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 8;
}

void CardEight::ReadCardParameters(Grid* pGrid)
{
}

void CardEight::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);
	pPlayer->SetIsCardEight(true);
}

void CardEight::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << endl;
}


void CardEight::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
}

CardEight::~CardEight(void)
{
}
