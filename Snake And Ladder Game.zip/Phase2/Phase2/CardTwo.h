#pragma once

#include "Card.h"
#include "fstream"

class CardTwo : public Card
{
	// CardTwo Parameters:
	int walletAmount; // the wallet value to increase from the player

public:
	CardTwo(const CellPosition& pos); // A Constructor takes card position
	CardTwo(const CellPosition& pos, int wallet); // A Constructor that takes card position and wallet ( for loading grid)

	virtual void ReadCardParameters(Grid* pGrid); // Reads the parameters of CardTwo which is: walletAmount

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of CardOne on the passed Player
													  // by decrementing the player's wallet by the walletAmount data member


	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	virtual ~CardTwo(); // A Virtual Destructor
};

