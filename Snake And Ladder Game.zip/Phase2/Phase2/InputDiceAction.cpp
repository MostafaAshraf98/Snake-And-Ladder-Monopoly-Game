#include "InputDiceAction.h"
#include "Grid.h"
#include "Player.h"
#include"Action.h"
#include"ApplicationManager.h"

InputDiceAction::InputDiceAction(ApplicationManager* pApp) : Action(pApp)
{

}

void InputDiceAction::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	pOut->PrintMessage("Input Dice Number:....");
	DiceNum = pIn->GetInteger(pOut);
	pOut->ClearStatusBar();
	return;


}




void InputDiceAction::Execute()
{

	// 1- Check if the Game is ended (Use the GetEndGame() function of pGrid), if yes, make the appropriate action
	Grid* pGrid = pManager->GetGrid();
	if (pGrid->GetEndGame() == true)
	{
		return;
	}
	else
	{

		// -- If not ended, do the following --:

		// 2- Get Number from User


		ReadActionParameters();
		// 3- Get the "current" player from pGrid

		Player* player = pGrid->GetCurrentPlayer();


		// 4- Move the currentPlayer using function Move of class player
		if (DiceNum > 0 && DiceNum < 7)
		{
			player->Move(pGrid, DiceNum);

			// 5- Advance the current player number of pGrid

			pGrid->AdvanceCurrentPlayer();
			return;
		}
		else
		{
			Grid* pGrid = pManager->GetGrid();
			Output* pOut = pGrid->GetOutput();
			pOut->PrintMessage("Invalid Dice Number..");

		}
	}
}

InputDiceAction::~InputDiceAction()
{

}