#include "CardSix.h"

CardSix::CardSix(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 6;
}

void CardSix::ReadCardParameters(Grid* pGrid)
{
}

void CardSix::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);
	CellPosition CellPos = pPlayer->GetCell()->GetCellPosition();
	CellPos.AddCellNum(pPlayer->GetJustRolledDiceNum() * -1);
	pGrid->UpdatePlayerCell(pPlayer, CellPos); // applying game object in the new cell is done in UpdateGamePlayer function
	
}


void CardSix::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << endl;
}


void CardSix::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
}



CardSix::~CardSix(void)
{
}
