#include "AddSnakeAction.h"

#include "Input.h"
#include "Output.h"
#include "Snake.h"
#include"Ladder.h"


AddSnakeAction::AddSnakeAction(ApplicationManager* pApp) : Action(pApp)
{
}


AddSnakeAction::~AddSnakeAction()
{
}


void AddSnakeAction::ReadActionParameters()
{
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	// Read the startPos parameter
	pOut->PrintMessage("New Snake: Click on its Start Cell ...");
	startPos = pIn->GetCellClicked();

	// Read the endPos parameter
	pOut->PrintMessage("New Snake: Click on its End Cell ...");
	endPos = pIn->GetCellClicked();





	if (startPos.VCell() > endPos.VCell()) //Validation that the snake is not upside down
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Error: Snake is upside down ! Click to continue ...");
		startPos = x;                     //If snake is upside down, return invalid cells
		endPos = x;
	}
	else if (endPos.GetCellNum() == 99)
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Error: Invalid end cell! Click to continue ...");

		startPos = x;                     //If ladder is upside down, return invalid cells
		endPos = x;
	}
	else if (startPos.GetCellNum() == 1)
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Error: Invalid start cell! Click to continue ...");

		startPos = x;                     //If ladder is upside down, return invalid cells
		endPos = x;
	}
	else if (startPos.HCell() != endPos.HCell())
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Snake is not Vertical. Click to Continue...");
		startPos = x;
		endPos = x;
	}

	pOut->ClearStatusBar();

}

void AddSnakeAction::Execute()
{

	ReadActionParameters();

	if (!(startPos.IsValidCell())) //Check that the cells are valid
	{
		return;
	}						  // Only need to check for 1 cell

	Snake* pSnake = new Snake(startPos, endPos);

	Grid* pGrid = pManager->GetGrid();
	GameObject* pGameObjectStart = pGrid->GetGameObject(startPos.VCell(), startPos.HCell());


	GameObject* pGameObjectEnd = pGrid->GetGameObject(endPos.VCell(), endPos.HCell());

	// CHECKING THE INFINITE LOOP CASE (START OF LADDER = END OF SNAKE)
	if (dynamic_cast<Ladder*>(pGameObjectEnd))
	{
		pGrid->PrintErrorMessage("Error: There is a Ladder. Click to Continue...");
		return;
	}



	// CHECKING OVERLAPPPING SNAKES (SNAKE INSIDE SNAKE)

	for (int i = 0; i < startPos.VCell(); i++)
	{
		CellPosition CellPos(i, startPos.HCell());
		GameObject* pGameObject = pGrid->GetGameObject(i, startPos.HCell());
		Snake* S = dynamic_cast<Snake*>(pGameObject);

		if (S != NULL)
		{
			if (S->GetEndPosition().VCell() > startPos.VCell())
			{
				pGrid->PrintErrorMessage("Error: Overlapping Snakes. Click to Continue..");
				return;
			}
		}
	}

	for (int i = startPos.VCell(); i < endPos.VCell(); i++)
	{
		CellPosition CellPos(i, startPos.HCell());
		GameObject* pGameObject = pGrid->GetGameObject(i, startPos.HCell());
		Snake* S = dynamic_cast<Snake*>(pGameObject);
		if (S != NULL)
		{

			pGrid->PrintErrorMessage("Error: Overlapping Snakes. Click to Continue..");
			return;

		}
	}

	bool added = pGrid->AddObjectToCell(pSnake);

	if (!added)
	{
		pGrid->PrintErrorMessage("Error: Cell already has an object ! Click to continue ...");
	}

}
