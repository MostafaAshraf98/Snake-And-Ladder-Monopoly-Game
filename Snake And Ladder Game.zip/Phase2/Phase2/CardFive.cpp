#include "CardFive.h"

CardFive::CardFive(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 5;
}

void CardFive::ReadCardParameters(Grid* pGrid)
{
}

void CardFive::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);
	CellPosition CellPos = pPlayer->GetCell()->GetCellPosition();
	CellPos.AddCellNum(pPlayer->GetJustRolledDiceNum());
	pGrid->UpdatePlayerCell(pPlayer, CellPos); // applying game object in the new cell is done in UpdateGamePlayer function
	if (CellPos.GetCellNum() == 99) // if he reaches end cell
		pGrid->SetEndGame(true);

}


void CardFive::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << endl;
}

void CardFive::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
}


CardFive::~CardFive(void)
{
}
