#include "CardTwelve.h"


CardTwelve::CardTwelve(const CellPosition& pos)
	:Card(pos)// set the cell position of the card
{
	cardNumber = 12; // set the inherited cardNumber data member with the card number (12 here)
}

CardTwelve::CardTwelve(CellPosition& pos, int cp, int rp) : Card(pos)
{
	cardNumber = 12;
	Price = cp;
	Fees = rp;
	isCreated = true;
}


int CardTwelve::Price = 0;
int CardTwelve::Fees = 0;
bool CardTwelve::isBought = false;//default value is that the card hasn't been bought
bool CardTwelve::isCreated = false; //default value is that it hasn't been created before
Player* CardTwelve::Owner = NULL; // in the begining the card doesn't have an owner
bool CardTwelve::IsSaved = false;

void  CardTwelve::ReadCardParameters(Grid* pGrid)
{

	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();
	int x, y;

	//checking using the static member fuction to see if i has been created before
	//if it has been created static data members will stay the same
	if (isCreated == false)

	{
		// getting card 10's price from the user
		pOut->PrintMessage("New CardEleven : Enter it's price: ");

		int p = pIn->GetInteger(pOut);
		while (p < 0)
		{
			pOut->PrintMessage(" Error!!Price can't be negative: Enter Price:");
			p = pIn->GetInteger(pOut);
		}
		Price = p;
		//then getting it's fees
		pOut->PrintMessage(" Enter it's fees:  ");

		int f = pIn->GetInteger(pOut);
		while (f < 0)
		{
			pOut->PrintMessage(" Error!!Fees can't be negative: Enter Fees:");
			f = pIn->GetInteger(pOut);
		}
		Fees = f;
		//setting isCreated 
		isCreated = true;
	}

	pOut->ClearStatusBar();
}


void CardTwelve::Apply(Grid* pGrid, Player* pPlayer)
{
	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();
	int x, y;
	Card::Apply(pGrid, pPlayer);    // to print the message to the user


	if (isBought == true)
	{
		pOut->PrintMessage("You have have to pay fees as this card has been bought   (click to continue)");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		pPlayer->SetWallet(pPlayer->GetWallet() - Fees);   // the player who steps on the card pays the fees
		Owner->SetWallet(Owner->GetWallet() + Fees);  // and gives them to the owner
		return;

	}
	else        //if the card is not owned by another player
	{
		if (Price < pPlayer->GetWallet())   // checking to see if the player has enough money
											//if he doesn't then he doesn't get the option to buy
		{
			pOut->PrintMessage("Do you want to buy CardTen for a price of " + to_string(Price) + " ?(y/n) ");


			//getting the answer from the user
			string s = pIn->GetSrting(pOut);
			if (s == "y")
			{
				pPlayer->SetWallet(pPlayer->GetWallet() - Price);
				isBought = true;
				Owner = pPlayer;
				pOut->ClearStatusBar();
				return;
			}
			else
			{
				pOut->ClearStatusBar();
				return;
			}
		}
		else
		{
			pGrid->PrintErrorMessage("You don't have enough money to buy this card  (click to continue)");
			return;
		}
	}

}

void CardTwelve::SetIsCreated(bool b)
{
	isCreated = b;
}





void CardTwelve::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	if (IsSaved == false)
	{
		Card::Save(OutFile, TYPE);
		OutFile << Price << " " << Fees << endl;
		IsSaved = true;
		return;
	}
	else
	{
		Card::Save(OutFile, TYPE);

	}
}


void CardTwelve::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
	int price = Price;
	int fees = Fees;
	Infile >> price >> fees;
}

CardTwelve::~CardTwelve()
{

}
