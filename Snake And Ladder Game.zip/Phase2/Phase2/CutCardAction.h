#pragma once
#include "Action.h"
class CutCardAction : public Action
{


	CellPosition CellPos;
	Card* ClipBoard;

	int CardNum;
public:

	CutCardAction(ApplicationManager* pApp);
	~CutCardAction();



	void ReadActionParameters();

	void Execute();

};
