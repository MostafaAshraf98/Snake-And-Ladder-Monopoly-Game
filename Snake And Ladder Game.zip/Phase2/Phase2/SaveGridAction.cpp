#include "SaveGridAction.h"



SaveGridAction::SaveGridAction(ApplicationManager *pApp) : Action(pApp)
{
	
}
string SaveGridAction::FileName = "test.txt";

void SaveGridAction::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("Save Grid. Please enter the file name ...");
	FileName=pIn->GetSrting(pOut);
	FileName = FileName + ".txt";
	pOut->PrintMessage("Click to continue ...");
	pIn->GetCellClicked();
	pOut->ClearStatusBar();
}


void SaveGridAction::Execute()
{
	ReadActionParameters();
	int x, y;
	Grid* pGrid = pManager->GetGrid();
	Input* pIn = (pGrid->GetInput());
	Output* pOut = (pGrid->GetOutput());
	ofstream OutFile; 
	OutFile.open(FileName, ios::out);
	
	if ( OutFile.is_open() )
	{
		
		pOut->PrintMessage("The file is opened and saving. Click to continue");
		pIn->GetPointClicked(x,y);
	}
	else 
	{
		pOut->PrintMessage("The file is NOT opened");
		pIn->GetPointClicked(x,y);
	}

	OutFile << pGrid->GetNumOfLadders() << endl;
	pGrid->SaveAll(OutFile, LADDER);
	OutFile << pGrid->GetNumOfSnakes() << endl;
	pGrid->SaveAll(OutFile, SNAKE);
	OutFile << pGrid->GetNumOfCards() << endl;
	pGrid->SaveAll(OutFile, CARD);
	OutFile.close();

	pOut->PrintMessage("Grid Saved Successfully");
	pIn->GetPointClicked(x,y);
	pOut->ClearStatusBar();
}


SaveGridAction::~SaveGridAction()
{
}
