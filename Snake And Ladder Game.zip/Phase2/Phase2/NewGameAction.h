#pragma once
#include "Action.h"
class NewGameAction : public Action
{

public:

	NewGameAction(ApplicationManager* pApp);
	void Execute();
	void ReadActionParameters();
	~NewGameAction();
};
