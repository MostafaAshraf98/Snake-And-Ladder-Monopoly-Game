#include "NewGameAction.h"
#include "Grid.h"
#include"CardTen.h"
#include"CardEleven.h"
#include"CardTwelve.h"
#include"CardThirteen.h"
#include"CardFourteen.h"


NewGameAction::NewGameAction(ApplicationManager* pApp) : Action(pApp)
{

}

void NewGameAction::ReadActionParameters()
{
	return;
}

void NewGameAction::Execute()
{
	Grid* pGrid = pManager->GetGrid(); // We get a pointer to the Grid from the ApplicationManager
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	
	CellPosition ResetPos(8, 0);


	for (int i = 0; i < 5; i++)
	{
		Player* player = pGrid->GetCurrentPlayer();

		pGrid->UpdatePlayerCell(player, ResetPos);
		player->SetWallet(100);
		player->SetTurnCount(0);
		player->SetIsCardEight(false);
		pGrid->AdvanceCurrentPlayer();
	}

	pGrid->ResetCurrentPlayer();
	CardTen::isBought = false;
	CardTen::Owner = NULL;
	CardEleven::isBought = false;
	CardEleven::Owner = NULL;
	CardTwelve::isBought = false;
	CardTwelve::Owner = NULL;
	CardThirteen::isBought = false;
	CardThirteen::Owner = NULL;
	CardFourteen::isBought = false;
	CardFourteen::Owner = NULL;

	pOut->CreateDesignModeToolBar();

	return;


}

NewGameAction::~NewGameAction()
{

}
