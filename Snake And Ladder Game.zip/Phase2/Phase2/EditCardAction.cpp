#include "EditCardAction.h"

#include "Input.h"
#include "Output.h"

#include "CardOne.h"
#include "CardTwo.h"
#include "CardThree.h"
#include "CardFour.h"
#include "CardFive.h"
#include "CardSix.h"
#include "CardSeven.h"
#include "CardEight.h"
#include "CardNine.h"
#include "CardTen.h"
#include "CardEleven.h"
#include "CardTwelve.h"
#include "CardThirteen.h"
#include "CardFourteen.h"
EditCardAction::EditCardAction(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer


}

EditCardAction::~EditCardAction()
{
}

void EditCardAction::ReadActionParameters() 	 //Function implemented by Nader
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	// Get the cell of the source to edit						

	pOut->PrintMessage("Click on the source to edit...");

	CardToEdit = pIn->GetCellClicked();






}

void EditCardAction::Execute()  //Implemented by Nader
{
	//  Get a Pointer to the Input / Output Interfaces  
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	ReadActionParameters();



	// Check if cell contains card or not , if yes, check if this card take values (card 1/22/9/10/11/12/13/14) or not




	int i = CardToEdit.VCell();
	int j = CardToEdit.HCell();



	Card* pCard = dynamic_cast<Card*>(pGrid->GetGameObject(i, j));

	if (pCard != NULL)
	{

		int Cardnum = (pCard->GetCardNumber());

		switch (Cardnum)
		{
		case(1):
		{
			pCard->ReadCardParameters(pGrid);
			break;
		}

		case(2):

		{
			pCard->ReadCardParameters(pGrid);
			break;
		}





		case(9):

		{
			pCard->ReadCardParameters(pGrid);
			break;

		}

		case(10):

		{
			((CardTen*)pCard)->SetIsCreated(false);
			pCard->ReadCardParameters(pGrid);
			break;
		}


		case(11):

		{
			((CardEleven*)pCard)->SetIsCreated(false);
			pCard->ReadCardParameters(pGrid);
			break;
		}

		case(12):

		{
			((CardTwelve*)pCard)->SetIsCreated(false);
			pCard->ReadCardParameters(pGrid);
			break;
		}


		case(13):

		{
			((CardThirteen*)pCard)->SetIsCreated(false);
			pCard->ReadCardParameters(pGrid);
			break;
		}
		break;

		case(14):

		{
			((CardFourteen*)pCard)->SetIsCreated(false);
			pCard->ReadCardParameters(pGrid);
			break;
		}
		default:
			pOut->PrintMessage("This Card takes no parameters");
		}
	}

	else

	{
		pGrid->PrintErrorMessage("Source Cell has no Card...");
		pOut->ClearStatusBar();

	}

	return;


}