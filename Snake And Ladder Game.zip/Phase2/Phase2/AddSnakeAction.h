#pragma once
#include "Action.h"
class AddSnakeAction : public Action
{
	CellPosition startPos;
	CellPosition endPos;
public:
	AddSnakeAction(ApplicationManager* pApp); //Constructor


	virtual void ReadActionParameters(); // read parameters startPos & endPos

	virtual void Execute();

	virtual ~AddSnakeAction();
};

