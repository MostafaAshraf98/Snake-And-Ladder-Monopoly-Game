#pragma once

#include "Card.h"
#include "fstream"

class CardNine : public Card
{
	int CellToMoveTo;

public:
	CardNine(const CellPosition& pos); // A Constructor takes card position
	CardNine(const CellPosition& pos, int cellnumber); //A Constructor that takes card position and CellToMoveTo (for loading grid)

	virtual void ReadCardParameters(Grid* pGrid);

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of CardNine on the passed Player
													  // by Instructing the player to go to specific cell

	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	void SetCellToMoveTo(int c);
	int GetCellToMoveTo();


	virtual ~CardNine(); // A Virtual Destructor
};
