#include"CopyCardAction.h"
#include"Output.h"
#include"Input.h"
#include"Grid.h"
#include"Card.h"


CopyCardAction::CopyCardAction(ApplicationManager* pApp) :Action(pApp)
{

}

CopyCardAction::~CopyCardAction()
{

}

void CopyCardAction::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();


	pOut->PrintMessage("Click on Source Cell...");


	CellPos = pIn->GetCellClicked();




}


void CopyCardAction::Execute()
{

	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	ReadActionParameters();



	int i = CellPos.VCell();
	int j = CellPos.HCell();

	GameObject* pGameObject = pGrid->GetGameObject(i, j);

	ClipBoard = dynamic_cast<Card*>(pGameObject);

	if (ClipBoard)
	{

		pGrid->SetClipboard(ClipBoard);
	}
	else
	{
		pGrid->PrintErrorMessage("Error: No Card on Source Cell...");

	}


	pOut->ClearStatusBar();



}



