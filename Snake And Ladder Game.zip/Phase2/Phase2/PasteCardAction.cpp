#include "PasteCardAction.h"
#include"CopyCardAction.h"
#include"Grid.h"
#include"Card.h"
#include"GameObject.h"
#include"Ladder.h"
#include"Snake.h"
#include"Output.h"
#include"Input.h"

#include "CardOne.h"
#include"CardTwo.h"
#include"CardThree.h"
#include"CardFour.h"
#include"CardFive.h"
#include"CardSix.h"
#include"CardSeven.h"
#include"CardEight.h"
#include"CardNine.h"
#include"CardTen.h"
#include "CardEleven.h"
#include "CardTwelve.h"
#include "CardThirteen.h"
#include "CardFourteen.h"

PasteCardAction::PasteCardAction(ApplicationManager* pApp) :Action(pApp)
{

}

PasteCardAction::~PasteCardAction()
{

}


void PasteCardAction::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();


	pOut->PrintMessage("Click on Cell Position:...");
	CellPos = pIn->GetCellClicked();

	pOut->ClearStatusBar();



}


void PasteCardAction::Execute()
{

	ReadActionParameters();

	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();

	ClipBoard = pGrid->GetClipboard();

	if (ClipBoard == NULL)
	{
		pGrid->PrintErrorMessage("Error: ClipBoard is Empty. Click to Continue...");
	}

	else if (CellPos.IsValidCell())
	{

		CardNum = ClipBoard->GetCardNumber();

		int i = CellPos.VCell();
		int j = CellPos.HCell();


		GameObject* pPrevObj = pGrid->GetGameObject(i, j);



		if (pPrevObj)
		{
			pGrid->PrintErrorMessage("Error: An object is already here. Click to Continue...");
		}




		else
		{
			ClipBoard->SetPosition(CellPos);
			pGrid->AddObjectToCell(ClipBoard);

		}
	}




	else
	{
		pGrid->PrintErrorMessage("Error: Invalid Cell Position...");
	}

}

