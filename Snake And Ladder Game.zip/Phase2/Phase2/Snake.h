#pragma once

#include "GameObject.h"
#include "fstream"

class Snake :public GameObject
{
protected:
	// Note: the "position" data member inherited from the GameObject class is used as the snake's "startCell Position"

	CellPosition endCellPos; // here is the snake's end Cell Position


public:
	Snake(const CellPosition& startCellPos, const CellPosition& endCellPos); // A constructor for initialization

	virtual void Draw(Output* pOut) const; // Draws a snake from its start cell to its end cell

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applys the effect of the snake by moving player to the snake's start cell

	CellPosition GetEndPosition() const; // A getter for the endCellPos data member

	virtual bool IsOverlapping(GameObject* newObj) const;

	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	virtual ~Snake(); // Virtual destructor

};