#pragma once
#include "Action.h"
class CopyCardAction : public Action
{


	CellPosition CellPos;
	Card* ClipBoard;

public:

	CopyCardAction(ApplicationManager* pApp);
	~CopyCardAction();



	void ReadActionParameters();

	void Execute();
};


