#include "CardThree.h"

CardThree::CardThree(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 3;
}

void CardThree::ReadCardParameters(Grid* pGrid)
{
}

void CardThree::Apply(Grid* pGrid, Player* pPlayer)
{

	Card::Apply(pGrid, pPlayer);
	CellPosition PlayerCurrPos = pPlayer->GetCell()->GetCellPosition();
	Ladder* NextLad = pGrid->GetNextLadder(PlayerCurrPos);
	if (NextLad != NULL)
	{
		CellPosition PlayerNewPos = NextLad->GetPosition();
		pGrid->UpdatePlayerCell(pPlayer, PlayerNewPos);
	}

}

void CardThree::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << endl;
}


void CardThree::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
}


CardThree::~CardThree(void)
{
}

