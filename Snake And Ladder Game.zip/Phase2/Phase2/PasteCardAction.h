#pragma once
#include "Action.h"
class PasteCardAction : public Action
{


	CellPosition CellPos;

	Card* ClipBoard;
	int CardNum;


public:
	PasteCardAction(ApplicationManager* pApp);

	~PasteCardAction();

	void Execute();


	void ReadActionParameters();
};
