#include "GameObject.h"


GameObject::GameObject(const CellPosition& pos)
{
	position = pos; // Sets Position
}

CellPosition GameObject::GetPosition() const
{
	return position;
}

bool GameObject::IsOverlapping(GameObject* newObj) const
{
	if (newObj != NULL && newObj->GetPosition().GetCellNum() == position.GetCellNum())
	{
		return true;
	}
	return false;
}

GameObject::~GameObject()
{
}


void GameObject::SetPosition(CellPosition CellPos)
{
	position = CellPos;
}
