#include "Card.h"
#include "fstream"
class CardSix : public Card
{

public:
	CardSix(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid);

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of CardSix on the passed Player
													  // by Moving the player backward the same number of steps that he just rolled

	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	virtual ~CardSix(); // A Virtual Destructor
};

