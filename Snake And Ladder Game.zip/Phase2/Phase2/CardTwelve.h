#pragma once
#include"Card.h"
#include "fstream"


class CardTwelve : public Card
{

	static int Price;
	static int Fees;

	static bool isCreated; // to check i it has been created before
	static bool IsSaved;
public:

	static bool isBought;//to check to see if the card has been bought by another player
	static Player* Owner;  // the player who owns the cell
	CardTwelve(const CellPosition& pos);
	CardTwelve(CellPosition& pos, int cp, int rp); // A Constructor for OpenGridAction
	virtual void ReadCardParameters(Grid* pGrid); // It reads the parameters specific for each Card Type


	virtual void Apply(Grid* pGrid, Player* pPlayer);  // It applies the effect of the Card Type on the passed player
													   // here the apply fuction is either buying the card or paying its fees

	void SetIsCreated(bool b);//to be able to edit the card

	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);


	virtual ~CardTwelve(); //a virtual destructor
};

