#include "Ladder.h"
#include "Snake.h"

Ladder::Ladder(const CellPosition& startCellPos, const CellPosition& endCellPos) : GameObject(startCellPos)
{
	///TODO: Do the needed validation

	this->endCellPos = endCellPos;

}

void Ladder::Draw(Output* pOut) const
{
	pOut->DrawLadder(position, endCellPos);
}

void Ladder::Apply(Grid* pGrid, Player* pPlayer)
{

	///TODO: Implement this function as mentioned in the guideline steps (numbered below) below


	// == Here are some guideline steps (numbered below) to implement this function ==

	// 1- Print a message "You have reached a ladder. Click to continue ..." and wait mouse click
	pGrid->PrintErrorMessage("You have reached ladder. Click to continue ...");


	// 2- Apply the ladder's effect by moving the player to the endCellPos
	//    Review the "pGrid" functions and decide which function can be used for that
	pGrid->UpdatePlayerCell(pPlayer, this->endCellPos);

}

CellPosition Ladder::GetEndPosition() const
{
	return endCellPos;
}

bool Ladder::IsOverlapping(GameObject* newObj) const
{

	return false;
}

void Ladder::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	if (TYPE == LADDER)
	{
		OutFile << to_string(position.GetCellNum()) << "  " << to_string(endCellPos.GetCellNum()) << endl;
		return;
	}
	else
	{
		return; //returns without saving in case passed type is not a ladder type
	}
}

void Ladder::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	int startcell = position.GetCellNum();
	int endcell = endCellPos.GetCellNum();
	if (TYPE == LADDER)
	{
		Infile >> startcell >> endcell;
	}
}

Ladder::~Ladder()
{
}
