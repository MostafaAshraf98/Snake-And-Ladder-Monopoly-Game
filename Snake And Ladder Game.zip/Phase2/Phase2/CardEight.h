#pragma once

#include "Card.h"
#include "Action.h"
#include "RollDiceAction.h"
#include "fstream"

class CardEight : public Card
{

public:
	CardEight(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid);

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of CardEight on the passed Player
													  // by preventing player from rolling next turn

	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	virtual ~CardEight(); // A Virtual Destructor
};

