#include "DeleteObjectAction.h"
#include "Input.h"
#include "Output.h"
#include "Grid.h"
#include "Card.h"
#include "CellPosition.h"


DeleteObjectAction::DeleteObjectAction(ApplicationManager* pApp) : Action(pApp)
{

}

DeleteObjectAction::~DeleteObjectAction()
{

}


void DeleteObjectAction::ReadActionParameters()
{

	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	pOut->PrintMessage("Choose an object to Delete..");
	CardToDelete = pIn->GetCellClicked();
	pOut->ClearStatusBar();





}
void DeleteObjectAction::Execute()
{
	ReadActionParameters();


	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	Cell* CardCell = new Cell(CardToDelete);


	int i = CardCell->GetCellPosition().VCell();
	int j = CardCell->GetCellPosition().HCell();


	GameObject* pGameObject = pGrid->GetGameObject(i, j);

	if (pGameObject)
	{


		pGrid->RemoveObjectFromCell(CardCell->GetCellPosition());

	}
	else
	{
		pOut->PrintMessage("No Object to delete..");
	}

}



