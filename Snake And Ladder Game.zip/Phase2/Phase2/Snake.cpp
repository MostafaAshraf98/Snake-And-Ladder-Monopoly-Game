#include "Snake.h"


Snake::Snake(const CellPosition& startCellPos, const CellPosition& endCellPos)
	:GameObject(startCellPos)
{
	//validation for being in the same vertical line and valid cell positions
	if (startCellPos.VCell() < endCellPos.VCell() && startCellPos.HCell() == endCellPos.HCell() && startCellPos.GetCellNum() != 99 && endCellPos.IsValidCell() && startCellPos.IsValidCell())
		this->endCellPos = endCellPos;

}

void Snake::Draw(Output* pOut) const
{
	pOut->DrawSnake(position, endCellPos);
}

void Snake::Apply(Grid* pGrid, Player* pPlayer)
{
	// 1- Print a message "You have reached a snake. Click to continue ..." and wait mouse click
	pGrid->PrintErrorMessage("You have reached snake. Click to continue ...");


	// 2- Apply the ladder's effect by moving the player to the endCellPos
	//    Review the "pGrid" functions and decide which function can be used for that
	pGrid->UpdatePlayerCell(pPlayer, this->endCellPos);

}

CellPosition  Snake::GetEndPosition() const
{
	return endCellPos;
}

bool  Snake::IsOverlapping(GameObject* newObj) const
{
	return false;


}

void Snake::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	if (TYPE == SNAKE)
	{
		OutFile << position.GetCellNum() << "  " << endCellPos.GetCellNum() << endl;
		return;
	}
	else
	{
		return; //returns without saving in case passed type is not a Snake type
	}
}


void Snake::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	int startcell = position.GetCellNum();
	int endcell = endCellPos.GetCellNum();
	if (TYPE == SNAKE)
	{
		Infile >> startcell >> endcell;
	}
}


Snake::~Snake()
{

}