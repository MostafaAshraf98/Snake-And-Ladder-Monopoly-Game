#include "Card.h"


Card::Card(const CellPosition& pos) : GameObject(pos) // sets the cell position of the GameObject
{
}

void Card::SetCardNumber(int cnum)
{
	if (1 <= cnum && cnum <= 14)
		cardNumber = cnum; // needs validation
}

int Card::GetCardNumber()
{
	return cardNumber;
}

void Card::Draw(Output* pOut) const
{

	///TODO: call the appropriate Ouput function that draws a cell containing the "cardNumber" in "position"
	if (position.IsValidCell() == true)
		pOut->DrawCell(position, cardNumber);

}

void Card::ReadCardParameters(Grid* pGrid)
{
	// we should not make it pure virtual because some Cards doesn't have parameters
	// and if we make it pure virtual, that will make those Cards abstract classes
}

bool Card::IsOverlapping(GameObject* newObj) const
{
	Card* c = dynamic_cast<Card*>(newObj);

	if (c != NULL && c->GetPosition().GetCellNum() == position.GetCellNum())
		return true;
	return false;
}

void Card::Apply(Grid* pGrid, Player* pPlayer)
{
	// As written below the "Roll Dice" action in the document ==> Check the Project Document
	// "If a player reaches a card of any other type", the following message should be printed then wait mouse click

	pGrid->PrintErrorMessage("You have reached card " + to_string(cardNumber) + ". Click to continue ...");
}

void Card::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	if (TYPE == CARD)
	{
		OutFile << cardNumber << "  " << position.GetCellNum() << "  ";
		return;
	}
	else
	{
		return; //returns without saving in case passed type is not a Card type
	}
}

void Card::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	int startcell = position.GetCellNum();
	if (TYPE == CARD)
	{
		Infile >> startcell;
	}
}

Card::~Card()
{
}
