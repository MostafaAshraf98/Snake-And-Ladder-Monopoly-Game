#include "CardTwo.h"

CardTwo::CardTwo(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 2;
}


CardTwo::CardTwo(const CellPosition& pos, int wallet) : Card(pos)
{
	cardNumber = 2;
	walletAmount = wallet;
}

void CardTwo::ReadCardParameters(Grid* pGrid)
{
	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();

	pOut->PrintMessage("New CardTwo: Enter its wallet amount");
	walletAmount = pIn->GetInteger(pOut);
	while (walletAmount < 0)
	{
		pOut->PrintMessage("Error! negative wallet amout, Please reenter positive amount");
		walletAmount = pIn->GetInteger(pOut);
	}

	pOut->ClearStatusBar();

}

void CardTwo::Apply(Grid* pGrid, Player* pPlayer)
{

	Card::Apply(pGrid, pPlayer);
	pPlayer->SetWallet(pPlayer->GetWallet() + walletAmount);

}
CardTwo::~CardTwo(void)
{
}


void CardTwo::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << walletAmount << endl;
}

void CardTwo::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
	int wallet = walletAmount;
	Infile >> wallet;
}



