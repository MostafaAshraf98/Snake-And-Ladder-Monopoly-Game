#pragma once
#include "Action.h"
#include "OpenGridAction.h"
#include "SaveGridAction.h"
#include "Ladder.h"
#include "Snake.h"
#include "Card.h"
#include "CardOne.h"
#include "CardTwo.h"
#include "CardThree.h"
#include "CardFour.h"
#include "CardFive.h"
#include "CardSix.h"
#include "CardSeven.h"
#include "CardEight.h"
#include "CardNine.h"
#include "CardTen.h"
#include "CardEleven.h"
#include "CardTwelve.h"
#include "CardThirteen.h"
#include "CardFourteen.h"

#include "Output.h"
#include "Input.h"

class OpenGridAction :
	public Action
{
	static string FileName;
public:
	OpenGridAction(ApplicationManager *pApp); // Constructor

	virtual void ReadActionParameters();

	virtual void Execute();

	virtual ~OpenGridAction(); // Virtual Destructor
};

