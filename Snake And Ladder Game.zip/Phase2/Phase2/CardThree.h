#pragma once

#include "Card.h"
#include "Ladder.h"
#include "fstream"
class CardThree : public Card
{

public:
	CardThree(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid);

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of CardThree on the passed Player
													  // by Moving the player forward to the next ladder

	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	virtual ~CardThree(); // A Virtual Destructor
};