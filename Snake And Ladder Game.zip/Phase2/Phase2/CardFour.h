#pragma once

#include "Card.h"
#include "Snake.h"
#include "fstream"

class CardFour : public Card
{

public:
	CardFour(const CellPosition& pos); // A Constructor takes card position

	virtual void ReadCardParameters(Grid* pGrid);

	virtual void Apply(Grid* pGrid, Player* pPlayer); // Applies the effect of CardFour on the passed Player
													  // by Moving the player forward to the next Snake


	virtual void Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE);
	virtual void Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE);

	virtual ~CardFour(); // A Virtual Destructor
};
