#include "AddLadderAction.h"

#include "Input.h"
#include "Output.h"
#include "Ladder.h"
#include"Snake.h"


AddLadderAction::AddLadderAction(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

AddLadderAction::~AddLadderAction()
{
}

void AddLadderAction::ReadActionParameters()
{
	// Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	// Read the startPos parameter
	pOut->PrintMessage("New Ladder: Click on its Start Cell ...");
	startPos = pIn->GetCellClicked();

	// Read the endPos parameter
	pOut->PrintMessage("New Ladder: Click on its End Cell ...");
	endPos = pIn->GetCellClicked();




	///TODO: Make the needed validations on the read parameters

	if (startPos.VCell() < endPos.VCell()) //Validation that the ladder is not upside down
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Error: Ladder is upside down ! Click to continue ...");
		startPos = x;                     //If ladder is upside down, return invalid cells
		endPos = x;
	}

	else if (endPos.GetCellNum() == 99)
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Error: Invalid end cell! Click to continue ...");

		startPos = x;                     //If ladder is upside down, return invalid cells
		endPos = x;
	}
	else if (startPos.GetCellNum() == 1)
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Error: Invalid start cell! Click to continue ...");

		startPos = x;                     //If ladder is upside down, return invalid cells
		endPos = x;
	}
	else if (startPos.HCell() != endPos.HCell())
	{
		CellPosition x;
		pGrid->PrintErrorMessage("Ladder is not Vertical. Click to Continue...");
		startPos = x;
		endPos = x;
	}

	// Clear messages
	pOut->ClearStatusBar();
}


// Execute the action
void AddLadderAction::Execute()
{
	// The first line of any Action Execution is to read its parameter first 
	// and hence initializes its data members
	ReadActionParameters();

	if (!(startPos.IsValidCell())) //Check that the cells are valid
	{
		return;
	}						  // Only need to check for 1 cell


 // Create a Ladder object with the parameters read from the user
	Ladder* pLadder = new Ladder(startPos, endPos);

	Grid* pGrid = pManager->GetGrid(); // We get a pointer to the Grid from the ApplicationManager


	//CHECKING IF THERE IS AN OBJECT AT START OF LADDER
	GameObject* pGameObjectStart = pGrid->GetGameObject(startPos.VCell(), startPos.HCell());
	if (pLadder->IsOverlapping(pGameObjectStart))
	{
		pGrid->PrintErrorMessage("Error: Is Overlapping! Click to continue...");
	}
	// Add the card object to the GameObject of its Cell:


	// CHECKING THE INFINITE LOOP CASE (START OF LADDER = END OF SNAKE)
	GameObject* pGameObjectEnd = pGrid->GetGameObject(endPos.VCell(), endPos.HCell());

	if (dynamic_cast<Snake*>(pGameObjectEnd))
	{
		pGrid->PrintErrorMessage("Error: There is a Snake! Click to continue ..");
		return;
	}


	// CHECKING OVERLAPPPING LADDERS (LADDER INSIDE LADDER)
	for (int i = 8; i > startPos.VCell(); i--)
	{
		CellPosition CellPos(i, startPos.HCell());
		GameObject* pGameObject = pGrid->GetGameObject(i, startPos.HCell());
		Ladder* L = dynamic_cast<Ladder*>(pGameObject);

		if (L != NULL)
		{
			if (L->GetEndPosition().VCell() < startPos.VCell())
			{
				pGrid->PrintErrorMessage("Error: Overlapping Ladders. Click to Continue..");
				return;
			}
		}
	}

	for (int i = startPos.VCell(); i > endPos.VCell(); i--)
	{
		CellPosition CellPos(i, startPos.HCell());
		GameObject* pGameObject = pGrid->GetGameObject(i, startPos.HCell());
		Ladder* L = dynamic_cast<Ladder*>(pGameObject);
		if (L != NULL)
		{

			pGrid->PrintErrorMessage("Error: Overlapping Ladders. Click to Continue..");
			return;

		}
	}

	bool added = pGrid->AddObjectToCell(pLadder);

	// if the GameObject cannot be added
	if (!added)
	{
		// Print an appropriate message
		pGrid->PrintErrorMessage("Error: Cell already has an object ! Click to continue ...");
	}
	// Here, the ladder is created and added to the GameObject of its Cell, so we finished executing the AddLadderAction

}
