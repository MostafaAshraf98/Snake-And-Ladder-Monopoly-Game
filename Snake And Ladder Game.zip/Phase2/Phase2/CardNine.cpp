#include "CardNine.h"

CardNine::CardNine(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 9;
}

void CardNine::ReadCardParameters(Grid* pGrid)
{
	
	Input* pIn = pGrid->GetInput();
	Output* pOut = pGrid->GetOutput();

	pOut->PrintMessage("New CardNine: Enter the cell to move to");

	CellToMoveTo = pIn->GetInteger(pOut);
	while (1 > CellToMoveTo || CellToMoveTo > 99)
	{
		pOut->PrintMessage("Invalid cell! Please reenter cell to move to");
		CellToMoveTo = pIn->GetInteger(pOut);
	}

	pOut->ClearStatusBar();

}

CardNine::CardNine(const CellPosition& pos, int cellnumber) : Card(pos)
{
	cardNumber = 9;
	CellToMoveTo = cellnumber;
}


void CardNine::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);
	CellPosition NewCell(CellToMoveTo);
	pGrid->UpdatePlayerCell(pPlayer, NewCell);
}


void CardNine::SetCellToMoveTo(int c)
{
	CellToMoveTo = c;

}
int CardNine::GetCellToMoveTo()
{
	return CellToMoveTo;
}


void CardNine::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << CardNine::GetCellToMoveTo() << endl;
}

void CardNine::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
	int CellNumb = CardNine::GetCellToMoveTo();
	Infile >> CellNumb;
}


CardNine::~CardNine(void)
{
}
