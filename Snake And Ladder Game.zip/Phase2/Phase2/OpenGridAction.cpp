#include "OpenGridAction.h"


OpenGridAction::OpenGridAction(ApplicationManager *pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

string OpenGridAction::FileName = "test";

void OpenGridAction::ReadActionParameters()
{
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();
	pOut->PrintMessage("Open Grid. Please enter file name ...");
	FileName = pIn->GetSrting(pOut);
	FileName = FileName + ".txt" ;
	pOut->PrintMessage("Click to continue ...");
	pIn->GetCellClicked();
	pOut->ClearStatusBar();
}


void OpenGridAction::Execute()
{
	ReadActionParameters();
	int x,y;
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	ifstream InFile;
	InFile.open(FileName, ios::in);
	int countladders;
	InFile >> countladders;
	for (int i = 0; i < countladders; i++)
	{
		int startcellnb=0;
		int endcellnb=0;
		InFile >> startcellnb >> endcellnb;
		CellPosition startcell;
		CellPosition endcell;
		GameObject* pGobj = new Ladder(startcell.GetCellPositionFromNum(startcellnb), endcell.GetCellPositionFromNum(endcellnb));
		pGrid->AddObjectToCell(pGobj);
	}
	int countSnakes;
	InFile >> countSnakes;
	for (int i = 0; i < countSnakes; i++)
	{
		int startcellnb = 0;
		int endcellnb = 0;
		InFile >> startcellnb >> endcellnb;
		CellPosition startcell;
		CellPosition endcell;
		GameObject* pGobj = new Snake(startcell.GetCellPositionFromNum(startcellnb), endcell.GetCellPositionFromNum(endcellnb));
		pGrid->AddObjectToCell(pGobj);
	}
	bool c10_opened = false;
	bool c11_opened = false;
	bool c12_opened = false;
	bool c13_opened = false;
	bool c14_opened = false;

	int c10_w, c10_f, c11_w, c11_f, c12_w, c12_f, c13_w, c13_f, c14_w, c14_f = 0;

	int countCards;
	InFile >> countCards;
	for (int i = 0; i < countCards; i++)
	{
		int cardnumb=0;
		InFile >> cardnumb;
		if (cardnumb ==1)
		{
			int cellnumb = 0;
			int wallet = 0;
			InFile >> cellnumb >> wallet;
			CellPosition cellpos;
			GameObject* pGobj = new CardOne(cellpos.GetCellPositionFromNum(cellnumb), wallet);
			pGrid->AddObjectToCell(pGobj);
		}
		if (cardnumb == 2)
		{
			int cellnumb = 0;
			int wallet = 0;
			InFile >> cellnumb >> wallet;
			CellPosition cellpos;
			GameObject* pGobj = new CardTwo(cellpos.GetCellPositionFromNum(cellnumb), wallet);
			pGrid->AddObjectToCell(pGobj);
		}
		if (cardnumb == 3)
		{
			int cellnumb;
			InFile >> cellnumb;
			CellPosition cellpos;
			GameObject* pobj = new CardThree(cellpos.GetCellPositionFromNum(cellnumb));
			pGrid->AddObjectToCell(pobj);
		}
		if (cardnumb == 4)
		{
			int cellnumb;
			InFile >> cellnumb;
			CellPosition cellpos;
			GameObject* pobj = new CardFour(cellpos.GetCellPositionFromNum(cellnumb));
			pGrid->AddObjectToCell(pobj);
		}
		if (cardnumb == 5)
		{
			int cellnumb;
			InFile >> cellnumb;
			CellPosition cellpos;
			GameObject* pobj = new CardFive(cellpos.GetCellPositionFromNum(cellnumb));
			pGrid->AddObjectToCell(pobj);
		}
		if (cardnumb == 6)
		{
			int cellnumb;
			InFile >> cellnumb;
			CellPosition cellpos;
			GameObject* pobj = new CardSix(cellpos.GetCellPositionFromNum(cellnumb));
			pGrid->AddObjectToCell(pobj);
		}
		if (cardnumb == 7)
		{
			int cellnumb;
			InFile >> cellnumb;
			CellPosition cellpos;
			GameObject* pobj = new CardSeven(cellpos.GetCellPositionFromNum(cellnumb));
			pGrid->AddObjectToCell(pobj);
		}
		if (cardnumb == 8)
		{
			int cellnumb;
			InFile >> cellnumb;
			CellPosition cellpos;
			GameObject* pobj = new CardFive(cellpos.GetCellPositionFromNum(cellnumb));
			pGrid->AddObjectToCell(pobj);
		}
		if(cardnumb == 9)
		{
			int cellnumb = 0;
			int celltomoveto = 0;
			InFile >> cellnumb >> celltomoveto;
			CellPosition cellpos;
			GameObject* pGobj = new CardNine(cellpos.GetCellPositionFromNum(cellnumb), celltomoveto);
			pGrid->AddObjectToCell(pGobj);
		}
		if (cardnumb == 10 && c10_opened == false)
		{
			int cellnumb;
			int rent;
			int cardprice;

			InFile >> cellnumb >> cardprice >> rent;
			CellPosition cellpos;
			GameObject* pobj = new CardTen(cellpos.GetCellPositionFromNum(cellnumb), cardprice, rent);
			pGrid->AddObjectToCell(pobj);
			c10_opened = true;
			c10_w = cardprice;
			c10_f = rent;
		}
		else if (cardnumb == 10 && c10_opened == true )
		{
			int cellnumb;
			InFile >> cellnumb;

			CellPosition cellpos;
			GameObject* pobj = new CardTen(cellpos.GetCellPositionFromNum(cellnumb), c10_w, c10_f);
			pGrid->AddObjectToCell(pobj);
		}

		if (cardnumb == 11 && c11_opened == false)
		{
			int cellnumb;
			int rent;
			int cardprice;

			InFile >> cellnumb >> cardprice >> rent;
			CellPosition cellpos;
			GameObject* pobj = new CardEleven(cellpos.GetCellPositionFromNum(cellnumb), cardprice, rent);
			pGrid->AddObjectToCell(pobj);
			c11_opened == true;
			c11_w = cardprice;
			c11_f = rent;
		}
		else if (cardnumb == 11 && c11_opened == true )
		{
			int cellnumb;
			InFile >> cellnumb;

			CellPosition cellpos;
			GameObject* pobj = new CardEleven(cellpos.GetCellPositionFromNum(cellnumb), c11_w, c11_f);
			pGrid->AddObjectToCell(pobj);
		}

		if (cardnumb == 12 && c12_opened == false)
		{
			int cellnumb;
			int rent;
			int cardprice;

			InFile >> cellnumb >> cardprice >> rent;
			CellPosition cellpos;
			GameObject* pobj = new CardTwelve(cellpos.GetCellPositionFromNum(cellnumb), cardprice, rent);
			pGrid->AddObjectToCell(pobj);
			c12_opened = true;
			c12_w = cardprice;
			c12_f = rent;
		}
		else if (cardnumb == 12 && c12_opened == true)
		{
			int cellnumb;
			InFile >> cellnumb;

			CellPosition cellpos;
			GameObject* pobj = new CardTwelve(cellpos.GetCellPositionFromNum(cellnumb), c12_w, c12_f);
			pGrid->AddObjectToCell(pobj);
		}

		if (cardnumb == 13 && c13_opened == false)
		{
			int cellnumb;
			int rent;
			int cardprice;

			InFile >> cellnumb >> rent >> cardprice;
			CellPosition cellpos;
			GameObject* pobj = new CardThirteen(cellpos.GetCellPositionFromNum(cellnumb), cardprice, rent);
			pGrid->AddObjectToCell(pobj);
			c13_opened = true;
			c13_w = cardprice;
			c13_f = rent;
		}
		else if (cardnumb == 13 && c13_opened == true)
		{
			int cellnumb;
			InFile >> cellnumb;

			CellPosition cellpos;
			GameObject* pobj = new CardThirteen(cellpos.GetCellPositionFromNum(cellnumb), c13_w, c13_f);
			pGrid->AddObjectToCell(pobj);
		}

		if (cardnumb == 14 && c14_opened == false)
		{
			int cellnumb;
			int rent;
			int cardprice;

			InFile >> cellnumb >> rent >> cardprice;
			CellPosition cellpos;
			GameObject* pobj = new CardFourteen(cellpos.GetCellPositionFromNum(cellnumb), cardprice, rent);
			pGrid->AddObjectToCell(pobj);
			c14_opened = true;
			c14_w = cardprice;
			c14_f = rent;
		}
		else if (cardnumb == 14 && c14_opened == true)
		{
			int cellnumb;
			InFile >> cellnumb;

			CellPosition cellpos;
			GameObject* pobj = new CardFourteen(cellpos.GetCellPositionFromNum(cellnumb), c14_w, c14_f);
			pGrid->AddObjectToCell(pobj);
		}

	}
	InFile.close();
	pOut->PrintMessage("Grid is loading. Click to continue ");
	pIn->GetPointClicked(x,y);
	pOut->ClearStatusBar();
}


OpenGridAction::~OpenGridAction()
{
	
}
