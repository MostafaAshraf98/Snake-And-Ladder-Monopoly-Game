#include "CardSeven.h"

CardSeven::CardSeven(const CellPosition& pos) : Card(pos) // set the cell position of the card
{
	cardNumber = 7;
}

void CardSeven::ReadCardParameters(Grid* pGrid)
{
}

void CardSeven::Apply(Grid* pGrid, Player* pPlayer)
{
	Card::Apply(pGrid, pPlayer);
	pGrid->SetCurrentPlayerNumber(pGrid->GetCurrPlayerNumber() - 1);
	// it gives the player another dice roll which involve the member function Move in class Player which increment the player's turn by 1

}


void CardSeven::Save(ofstream& OutFile, GAMEOBJECT_TYPE TYPE)
{
	Card::Save(OutFile, TYPE);
	OutFile << endl;
}


void CardSeven::Load(ifstream& Infile, GAMEOBJECT_TYPE TYPE)
{
	Card::Load(Infile, TYPE);
}


CardSeven::~CardSeven(void)
{
}
